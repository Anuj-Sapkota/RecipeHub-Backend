export const USER = "USER";
export const ADMIN = "ADMIN";
